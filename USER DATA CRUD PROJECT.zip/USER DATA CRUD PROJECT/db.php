<?php

//Database Connection in PHP

//Connecting MySql Database by using  OOP approach

session_start();
//session_destroy();
$servername= "localhost:3307";
$username = "root";
$password = "";
$dbname = "cruddatabase";

//Create Connection

$conn = @new mysqli($servername,$username,$password,$dbname);     

//Check Connection
if($conn->connect_error){
 die( "Connection failed"
. $conn->connect_error) ;
} 

// echo "Connection successfully". "<br>";

?>