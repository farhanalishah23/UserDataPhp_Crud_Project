<?php
include("db.php"); 

##Login Form submit
if(isset($_POST['submit'])){
   extract($_POST);
   
   #sql query to login
   $pass= md5($password);
   $sql = "SELECT * FROM users Where username = '$username' AND password = '$pass'";
   $result = $conn->query($sql);

if($result->num_rows){
$_SESSION['is_user_loggedin'] = true;
$_SESSION['datauser']=mysqli_fetch_assoc($result);
header("LOCATION: users.php");


}else{
  
    $_SESSION['error']=" login failed check you Username or Password";
}
}






?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="style.css" rel="stylesheet">
    <title>PHP CRUD Application</title>
</head>

<body>

    <section class="section">
       <?php include("alert.php") ?> 
        <h2>Login Form</h2>

        <form action="index.php" method="post">
            <div class="container">
                <label for="uname"><b>Username</b></label>
                <input type="text" placeholder="Enter Username" name="username" required>

                <label for="psw"><b>Password</b></label>
                <input type="password" placeholder="Enter Password" name="password" required>

                <button type="submit" name="submit">Login</button>

            </div>
        </form>
    </section>

</body>

</html>